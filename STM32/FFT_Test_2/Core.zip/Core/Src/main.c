#include "stm32l0xx_hal.h"
#include "arm_math.h"
#include "string.h"
#include "stdio.h"

#define BUFFER_SIZE 1024
#define FFT_LENGTH 1024
#define UART_BUFFER_SIZE (BUFFER_SIZE * sizeof(float32_t))  // Ensure it's large enough
#define SAMPLE_RATE 16000  // Define SAMPLE_RATE

UART_HandleTypeDef huart2;
float32_t input[BUFFER_SIZE];
float32_t fft_output[FFT_LENGTH];
float32_t fft_magnitude[FFT_LENGTH / 2];

uint8_t uart_buffer[UART_BUFFER_SIZE];
uint16_t uart_buffer_index = 0;

// Function prototypes
void SystemClock_Config(void);
void Error_Handler(void);
static void MX_USART2_UART_Init(void);
void apply_window(float32_t *data, uint16_t size);
void perform_fft(arm_rfft_fast_instance_f32 *fft_instance);

int main(void) {
    HAL_Init();
    SystemClock_Config();
    MX_USART2_UART_Init();

    arm_rfft_fast_instance_f32 fft_instance;
    arm_rfft_fast_init_f32(&fft_instance, FFT_LENGTH);

    while (1) {
        if (uart_buffer_index >= BUFFER_SIZE * sizeof(float32_t)) {
            // Convert UART buffer to float32_t input buffer
            memcpy(input, uart_buffer, BUFFER_SIZE * sizeof(float32_t));
            uart_buffer_index = 0;

            // Apply windowing and FFT
            apply_window(input, BUFFER_SIZE);
            perform_fft(&fft_instance);

            // Transmit FFT results via UART
            char buffer[50];
            for (int i = 0; i < FFT_LENGTH / 2; i++) {
                sprintf(buffer, "frequency %f: %f \n", ((float32_t)i * SAMPLE_RATE / FFT_LENGTH), fft_magnitude[i]);
                HAL_UART_Transmit(&huart2, (uint8_t*)buffer, strlen(buffer), HAL_MAX_DELAY);
            }
        }
    }
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {
    if (huart->Instance == USART2) {
        if (uart_buffer_index < UART_BUFFER_SIZE) {
            HAL_UART_Receive_IT(&huart2, &uart_buffer[uart_buffer_index], 1);
            uart_buffer_index++;
        }
    }
}

void apply_window(float32_t *data, uint16_t size) {
    for (int i = 0; i < size; i++) {
        data[i] *= 0.54 - 0.46 * cos(2 * PI * i / (size - 1));  // Hamming window
    }
}

void perform_fft(arm_rfft_fast_instance_f32 *fft_instance) {
    arm_rfft_fast_f32(fft_instance, input, fft_output, 0);
    arm_cmplx_mag_f32(fft_output, fft_magnitude, FFT_LENGTH / 2);
}

static void MX_USART2_UART_Init(void) {
    huart2.Instance = USART2;
    huart2.Init.BaudRate = 115200;
    huart2.Init.WordLength = UART_WORDLENGTH_8B;
    huart2.Init.StopBits = UART_STOPBITS_1;
    huart2.Init.Parity = UART_PARITY_NONE;
    huart2.Init.Mode = UART_MODE_TX_RX;
    huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
    huart2.Init.OverSampling = UART_OVERSAMPLING_16;
    huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
    if (HAL_UART_Init(&huart2) != HAL_OK) {
        Error_Handler();
    }
}

void SystemClock_Config(void) {
    // System Clock Configuration
}

void Error_Handler(void) {
    while (1) {
        // Stay in error handler
    }
}
